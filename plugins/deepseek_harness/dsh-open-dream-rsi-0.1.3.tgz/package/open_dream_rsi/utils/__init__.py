"""Helper utilities: policy evaluation."""
